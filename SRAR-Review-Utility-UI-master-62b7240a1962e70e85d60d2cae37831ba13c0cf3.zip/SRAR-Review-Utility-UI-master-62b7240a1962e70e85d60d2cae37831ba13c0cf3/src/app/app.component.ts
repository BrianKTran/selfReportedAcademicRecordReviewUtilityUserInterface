import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-header></app-header>
    <div class="container-fluid min-width-1100">
      <router-outlet></router-outlet>
    </div>`,
  styles: ['.min-width-1100 { min-width: 1100px;}']
})
export class AppComponent {
  constructor() {}
}
