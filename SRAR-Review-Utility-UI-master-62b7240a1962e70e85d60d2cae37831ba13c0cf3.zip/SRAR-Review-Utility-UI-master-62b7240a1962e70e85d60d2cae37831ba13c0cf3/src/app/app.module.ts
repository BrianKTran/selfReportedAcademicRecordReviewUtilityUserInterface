import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MyDatePickerModule } from 'mydatepicker';
import { ReactiveFormsModule } from '@angular/forms';

// 3rd Party
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { NgxPaginationModule } from 'ngx-pagination';

// Custom Modules
import { AppRoutingModule } from './routing/app-routing.module';

// Config
import { APP_INITIALIZER } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { Config } from './config.service';
import { AddHeaderInterceptor } from './HttpInterceptors/AddHeaderInterceptor';

// Custom Components
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SchoolListComponent } from './academic-record/ar-list/school-list.component';
import { SchoolListItemComponent } from './academic-record/ar-list/school-list-item.component';
import { SubmissionDetailComponent } from './submission/submission-detail/submission-detail.component';
import { SubmissionListComponent } from './submission/submission-list/submission-list.component';
import { SubmissionStatusLabelComponent } from './submission/submission-detail/submission-status-label.component';
import { SortableColumnComponent } from './sort/sortable-column.component';
import { CourseListComponent } from './course/course-list/course-list.component';
import { CourseListItemComponent } from './course/course-list-item/course-list-item.component';
import { CourseSubjectNumberPipe } from './pipes/CourseSubjectNumberPipe';
import { ConfirmComponent } from './dialog/confirm-dialog.component';
import { AuditLogComponent } from './dialog/audit-dialog.component';
import { SchoolEditDialogComponent } from './academic-record/school-edit/school-edit-dialog.component';
import { SchoolEditComponent } from './academic-record/school-edit/school-edit.component';
import { AcademicRecordEditDialogComponent} from './academic-record/ar-edit/academic-record-edit-dialog.component';
import { ErrorDialogComponent } from './dialog/error-dialog.component';
import { AuditComponent } from './audit/audit.component';
import { AuditItemComponent } from './audit/audit-item.component';
import { SubmissionInfoComponent } from './submission/submission-detail/submission-info/submission-info.component';

// Custom Services
import { CodeService } from './models/CodeService';
import { SingleSubmissionService } from '../app/submission/single-submission.service';
import { SearchSubmissionService } from '../app/submission/search-submission.service';
import {AcademicRecordService} from './academic-record/academic-record.service';
import {CourseService} from './course/course.service';
import {SortableTableDirective} from './sort/sortable-table.directive';
import {MatchHeightDirective} from './submission/submission-detail/submission-info/match-height.directive';
import {AutoApprovalFailureDialogComponent} from './dialog/auto-approval-failure-dialog.component';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    AppRoutingModule,
    MyDatePickerModule,
    ReactiveFormsModule,
    BootstrapModalModule.forRoot({container: document.body})
  ],
  declarations: [
    AppComponent,
    HeaderComponent,
    SchoolListComponent,
    SchoolListItemComponent,
    SubmissionInfoComponent,
    SubmissionListComponent,
    SubmissionDetailComponent,
    SubmissionStatusLabelComponent,
    CourseListComponent,
    CourseListItemComponent,
    CourseSubjectNumberPipe,
    ConfirmComponent,
    AuditLogComponent,
    ErrorDialogComponent,
    AutoApprovalFailureDialogComponent,
    AuditComponent,
    AuditItemComponent,
    SchoolEditDialogComponent,
    SchoolEditComponent,
    AcademicRecordEditDialogComponent,
    SortableTableDirective,
    SortableColumnComponent,
    MatchHeightDirective
  ],
  entryComponents: [
       ConfirmComponent,
       AuditLogComponent,
       AutoApprovalFailureDialogComponent,
       ErrorDialogComponent,
       SchoolEditDialogComponent,
       AcademicRecordEditDialogComponent
     ],
  providers: [CodeService, SearchSubmissionService, SingleSubmissionService, AcademicRecordService, CourseService, Config,
              {provide: APP_INITIALIZER, useFactory: onAppInit, deps: [Config, CodeService], multi: true},
              {provide: HTTP_INTERCEPTORS, useClass: AddHeaderInterceptor, deps: [Config], multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function onAppInit(config: Config, codeService: CodeService) {
  return () => {
    config.load();
    return codeService.init(config.getApiUrl());
  };
}
