import { Component } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
export interface AuditModel {
  psuId: string;
}
@Component({
    selector: 'app-audit-dialog',
    styleUrls: ['./audit-dialog.component.css'],
    template: `<div class="modal-dialog modal-lg">
                <div class="modal-content">
                   <div class="modal-header">
                     <button type="button" class="close" (click)="close()" >&times;</button>
                     <h4 class="modal-title">Audit Log</h4>
                   </div>
                   <div class="modal-body">
                    <app-audit-list [psuId]="psuId"></app-audit-list>
                   </div>
                   <div class="modal-footer">
                     <button type="button" class="btn btn-default" (click)="close()" >Close</button>
                   </div>
                 </div>
              </div>`
})
export class AuditLogComponent extends DialogComponent<AuditModel, boolean> implements AuditModel {
  psuId: string;
  constructor(dialogService: DialogService) {
    super(dialogService);
  }
  confirm() {
    this.close();
  }
}
