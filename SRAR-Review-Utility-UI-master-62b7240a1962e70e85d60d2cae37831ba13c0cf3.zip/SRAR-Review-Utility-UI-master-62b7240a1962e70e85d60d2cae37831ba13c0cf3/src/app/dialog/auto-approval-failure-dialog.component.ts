import { Component } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
export interface AutoApprovalFailuresModel {
  autoApprovalFailures: Array<any>;
}
@Component({
  selector: 'app-auto-approval-failures-dialog',
  styleUrls: ['./audit-dialog.component.css'],
  template: `<div class="modal-dialog modal-lg">
                <div class="modal-content">
                   <div class="modal-header">
                     <button type="button" class="close" (click)="close()" >&times;</button>
                     <h4 class="modal-title">Auto-approval Failures</h4>
                   </div>
                   <div class="modal-body">
                      <div *ngFor="let failure of autoApprovalFailures">{{failure.criteria}}</div>
                   </div>
                   <div class="modal-footer">
                     <button type="button" class="btn btn-default" (click)="close()" >Close</button>
                   </div>
                 </div>
              </div>`
})
export class AutoApprovalFailureDialogComponent extends DialogComponent<AutoApprovalFailuresModel, boolean>
  implements AutoApprovalFailuresModel {
  autoApprovalFailures: Array<any>;
  constructor(dialogService: DialogService) {
    super(dialogService);
  }
  confirm() {
    this.close();
  }
}
