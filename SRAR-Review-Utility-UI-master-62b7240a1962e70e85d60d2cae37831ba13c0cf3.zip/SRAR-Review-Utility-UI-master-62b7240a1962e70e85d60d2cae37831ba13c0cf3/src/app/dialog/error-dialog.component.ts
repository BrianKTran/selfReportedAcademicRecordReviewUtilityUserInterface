import { Component } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
export interface ErrorDialogModel {
  title: string;
  message: string;
  errors: Array<string>;
}
@Component({
    selector: 'add-course-error-dialog',
    template: `<div class="modal-dialog">
                <div class="modal-content">
                   <div class="modal-header">
                     <button type="button" class="close" (click)="close()" >&times;</button>
                     <h4 class="modal-title">{{title}}</h4>
                   </div>
                   <div class="modal-body">
                     <p>{{message}}</p>
                     <ng-container *ngFor='let error of errors; let i = index'>
                      <span class="text-danger">{{error}}</span>
                      <br *ngIf="i <= errors.length" />
                     </ng-container>
                   </div>
                   <div class="modal-footer">
                      <button type="button" class="btn btn-info" (click)="close()">Ok</button>
                   </div>
                 </div>
              </div>`
})
export class ErrorDialogComponent extends DialogComponent<ErrorDialogModel, boolean> implements ErrorDialogModel {
  title: string;
  message: string;
  errors: Array<string>;

  constructor(dialogService: DialogService) {
    super(dialogService);
  }
}
