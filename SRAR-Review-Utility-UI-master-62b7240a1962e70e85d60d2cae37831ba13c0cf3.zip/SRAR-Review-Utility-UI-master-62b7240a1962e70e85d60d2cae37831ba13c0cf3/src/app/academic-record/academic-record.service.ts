import {HttpClient} from '@angular/common/http';
import {Config} from '../config.service';
import {Srar} from '../models/Srar';
import {Observable} from 'rxjs/Observable';
import {Injectable, OnDestroy} from '@angular/core';
import {ErrorDialogComponent} from '../dialog/error-dialog.component';
import {DialogService} from 'ng2-bootstrap-modal';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {CourseService} from '../course/course.service';
import {SingleSubmissionService} from '../submission/single-submission.service';
import {tap} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

@Injectable()
export class AcademicRecordService {

  private baseSubmissionUrl = null;

  private _srars: Array<Srar> = null;
  private srarsUpdatedSubj: BehaviorSubject<Array<Srar>> = new BehaviorSubject<Array<Srar>>(null);
  public srarsUpdated: Observable<Array<Srar>> = this.srarsUpdatedSubj.asObservable();

  constructor(private http: HttpClient,
              private config: Config,
              private ds: DialogService,
              private submissionService: SingleSubmissionService,
              private courseService: CourseService) {

    this.baseSubmissionUrl = config.getApiUrl() + 'submissions/';

  }

  private onUpdateSrars(srars: Array<Srar>) {
    this._srars = srars;
    this.srarsUpdatedSubj.next(this._srars);
  }

  private triggerCoursesServerUpdate(): Observable<any> {
    return this.courseService.fetchCoursesForCurrentSubmission();
  }

  public get srars() {
    return this._srars;
  }

  public fetchSrarsByPsuId(psuId: string): Observable<any> {
    return this.http
      .get(this.baseSubmissionUrl + psuId + '/srars')
      .pipe(
        tap((data) => {
          this.onUpdateSrars(data);
        })
      );
  }

  public doSchoolSearch(params: any): Observable<any> {
    return this.http.get(this.config.getApiUrl() + 'schools', {
      params: params
    });
  }

  public create(psuId: string, srar: Srar): Observable<any> {
    return this.http.post(this.config.getApiUrl() + 'submissions/' + psuId + '/srars', srar)
      .pipe(
        tap(data => {
          this.srars.push(data);
          this.onUpdateSrars(this.srars);
        })
      );

  }

  public update(psuId: string, recordId: number, srar: Srar): Observable<any> {
    const url = this.config.getApiUrl() + 'submissions/' + psuId + '/srars/' + recordId;
    this.submissionService.lockSubmission();
    return this.http.put(url, srar)
      .pipe(
        tap(data => {
          const idx = this._srars.findIndex(el => recordId === el.recordId);
          if (idx >= 0) {
            this._srars[idx] = data;
            this.onUpdateSrars(this._srars);
            this.triggerCoursesServerUpdate().subscribe(() => {
              this.submissionService.unlockSubmission();
            });
          }
        })
      );
  }

  public delete(psuId: string, recordId: number): Observable<any> {
    const url = this.config.getApiUrl() + 'submissions/' + psuId + '/srars/' + recordId;
    return this.http.delete(url)
      .pipe(
        tap(data => {
          if (data === true) {
            this._srars.splice(this._srars.findIndex(sr => sr.recordId === recordId));
            this.onUpdateSrars(this._srars);
          } else {
            this.showFailedDeletePopup();
          }
        })
      );
  }

  private showFailedDeletePopup() {
    const disposable2 = this.ds.addDialog(ErrorDialogComponent, {
      title: 'Delete Error',
      message: 'Cannot delete record. Please correct following errors and try again.',
      errors: ['There are courses still associated with this record']
    })
      .subscribe(() => {
        disposable2.unsubscribe();
      });
  }
}
