import { Component, OnInit, OnDestroy } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { SchoolEditDialogComponent } from '../school-edit/school-edit-dialog.component';
import { AcademicRecordEditDialogComponent } from '../ar-edit/academic-record-edit-dialog.component';
import { SingleSubmissionService } from '../../submission/single-submission.service';
import { Srar } from '../../models/Srar';
import {AcademicRecordService} from '../academic-record.service';
import {Subscription} from 'rxjs/Subscription';
import {AcademicRecordUtil} from '../academic-record.util';

@Component({
  selector: 'app-school-list',
  templateUrl: './school-list.component.html'
})
export class SchoolListComponent implements OnInit, OnDestroy {

  public srars: Array<Srar>;

  public isLocked: boolean;

  private singleSubmissionSub: Subscription = null;
  private academicRecordSub: Subscription = null;

  public getStateOrProvince = AcademicRecordUtil.getStateOrProvinceFromSrar;
  public getAttendanceDates = AcademicRecordUtil.getAttendanceDates;

  constructor(private singleSubmissionService: SingleSubmissionService,
              private academicRecordService: AcademicRecordService,
              private schoolService: AcademicRecordService,
              private ds: DialogService) {

  }

  ngOnInit() {
    this.singleSubmissionSub = this.singleSubmissionService.submissionUpdated.subscribe(() => this.setLockedStatus());
    this.academicRecordSub = this.academicRecordService.srarsUpdated.subscribe((srars) => {
      this.srars = srars;
    });
  }

ngOnDestroy(){
  this.singleSubmissionSub.unsubscribe();
  this.academicRecordSub.unsubscribe();
}

  private setLockedStatus() {
    this.isLocked = this.singleSubmissionService.submission.isLocked;
  }

  public onAddSchoolClicked() {
    let disposable = this.ds.addDialog(SchoolEditDialogComponent, { srar: null  })
      .subscribe((srar1: Srar) => {
        if (srar1) {
          disposable.unsubscribe();
          disposable = this.ds.addDialog(AcademicRecordEditDialogComponent, { srar: srar1 }).subscribe(
            (srar2: Srar) => {
              if (srar2) {
                this.schoolService.create(this.singleSubmissionService.submission.psuId, srar2)
                  .subscribe(() => this.singleSubmissionService.refetchSubmission());
              }
            }
          );
        }
      });

  }

}
