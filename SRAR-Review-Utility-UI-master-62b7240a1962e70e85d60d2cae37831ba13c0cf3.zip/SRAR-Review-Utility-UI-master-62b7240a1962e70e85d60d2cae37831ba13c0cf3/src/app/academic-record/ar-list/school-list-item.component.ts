import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { SchoolEditDialogComponent } from '../school-edit/school-edit-dialog.component';
import { ConfirmComponent } from '../../dialog/confirm-dialog.component';
import { SingleSubmissionService } from '../../submission/single-submission.service';
import { School } from '../../models/School';
import { Srar } from '../../models/Srar';
import { AcademicRecordService } from '../academic-record.service';
import {AcademicRecordEditDialogComponent} from '../ar-edit/academic-record-edit-dialog.component';
import {AcademicRecordUtil} from '../academic-record.util';

@Component({
  selector: 'tr[srar]',
  templateUrl: './school-list-item.component.html'
})
export class SchoolListItemComponent implements OnInit {

  @Input()
  public srar: Srar;

  @Output()
  public onDeleted: EventEmitter<string> = new EventEmitter<string>();

  @Input()
  public listSize: number;

  public isLocked: boolean;

  public getStateOrProvince = AcademicRecordUtil.getStateOrProvinceFromSrar;
  public getAttendanceDates = AcademicRecordUtil.getAttendanceDates;

  constructor(private singleSubmissionService: SingleSubmissionService,
              private ds: DialogService,
              private arService: AcademicRecordService) {
    this.singleSubmissionService.submissionUpdated.subscribe(data => {
      this.setLockedStatus();
    });

  }

  ngOnInit() {
    if (!this.srar.school) {
      this.srar.school = new School();
    }
  }

  private setLockedStatus() {
    this.isLocked = this.singleSubmissionService.submission.isLocked;
  }


  public onEditSchool() {
    const srarCopy = Object.assign({}, this.srar);
    srarCopy.school = Object.assign({}, this.srar.school);
    let disposable = this.ds.addDialog(SchoolEditDialogComponent, {
      srar: srarCopy})
      .subscribe((srar1: Srar) => {
          // We get dialog result
        if (srar1) {
          disposable.unsubscribe();
          disposable = this.ds.addDialog(AcademicRecordEditDialogComponent, { srar: srar1 }).subscribe(
            (srar2: Srar) => {
              if (srar2) {
                this.arService.update(this.singleSubmissionService.submission.psuId, this.srar.recordId, srar2)
                  .subscribe(() => this.singleSubmissionService.refetchSubmission());
              }
            }
          );
        }
      });
  }

  public onDeleteSchool() {

    const disposable = this.ds.addDialog(ConfirmComponent,
      {title: 'Delete School', message: 'Are you sure you want to delete '
        + this.srar.ceebCode  + ' from the record?', type: 'delete'})
        .subscribe((result) => {
            // We get dialog result
            if (result) {
                this.arService.delete(this.srar.psuId, this.srar.recordId)
                  .subscribe(() => this.singleSubmissionService.refetchSubmission());
            }
            disposable.unsubscribe();
        });

  }
}
