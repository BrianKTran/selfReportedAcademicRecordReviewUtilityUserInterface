import {Component, OnInit} from '@angular/core';
import {DialogComponent, DialogService} from 'ng2-bootstrap-modal';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {School} from '../../models/School';
import {Srar} from '../../models/Srar';

export interface AddSchoolModel {
  srar: Srar;
}

@Component({
  selector: 'app-school-add-dialog',
  styleUrls: ['./academic-record-edit.component.css'],
  templateUrl: './academic-record-edit.component.html'
})
export class AcademicRecordEditDialogComponent extends DialogComponent<AddSchoolModel, Srar> implements AddSchoolModel, OnInit {

  // Cannot be null
  public srar: Srar;

  public form: FormGroup;

  constructor(dialogService: DialogService,
              private fb: FormBuilder) {

    super(dialogService);
  }

  ngOnInit() {
    this.createFormExistingSrar();
  }

  private createFormExistingSrar() {
    const srar = this.srar;
    this.form = this.fb.group({
      startDate: [srar.startDate, [Validators.required, Validators.pattern('^[0-9]{4}-[0-9]{2}$')]],
      endDate: [srar.endDate, [Validators.required, Validators.pattern('^[0-9]{4}-[0-9]{2}$')]],
      creditHoursAttempted: [srar.creditHoursAttempted, [Validators.pattern('[+-]?([0-9]*[.])?[0-9]+')]],
      creditHoursEarned: [srar.creditHoursEarned, [Validators.pattern('[+-]?([0-9]*[.])?[0-9]+')]],
      gpa: [srar.gpa, [Validators.pattern('[+-]?([0-9]*[.])?[0-9]+')]],
      classRank: [srar.classRank, Validators.pattern('[0-9]*')],
      classSize: [srar.classSize, Validators.pattern('[0-9]*')],
      decileRankUsed: srar.decileRankeUsed ? srar.decileRankeUsed.trim() : 'N',
      decileRankSelection: [srar.decileRankSelection
      && srar.decileRankSelection !== 'null'
        ? srar.decileRankSelection : '', [Validators.pattern('[+-]?([0-9]*[.])?[0-9]+')]],
      homeSchool: srar.homeSchool ? srar.homeSchool : 'N',
      nonRankingSchool: srar.nonRankingSchool ? srar.nonRankingSchool : 'N'
    });
  }

  formatSchoolAddress() {
    return School.formatAddress(this.srar.school);
  }

  confirm() {
    if (this.form.valid) {
      this.result = Object.assign({}, this.srar, this.form.value);
      this.close();
    }

  }

}
