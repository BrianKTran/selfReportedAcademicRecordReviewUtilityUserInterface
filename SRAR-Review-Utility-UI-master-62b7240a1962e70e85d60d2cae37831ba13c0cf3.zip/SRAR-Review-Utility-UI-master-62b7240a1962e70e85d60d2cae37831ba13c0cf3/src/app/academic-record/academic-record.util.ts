import {Srar} from '../models/Srar';
import {School} from '../models/School';
import {Course} from '../models/Course';

export class AcademicRecordUtil {

  public static getStateOrProvinceFromSrar(srar: Srar): string {
    const school: School = srar.school;
    return AcademicRecordUtil.getStateOrProvinceFromSchool(school);
  }

  public static getStateOrProvinceFromSchool(school: School) {
    if (school != null) {
      const sState = school.state;
      if (sState && sState.trim().length > 0) {
        return sState.trim();
      }
      const sProv = school.highSchoolProvince;
      if (sProv && sProv.trim().length > 0) {
        return sProv.trim();
      }
    }
    return '-';
  }

  public static getAttendanceDates(srar: Srar): string {
    const startDate: string = srar.startDate ? srar.startDate.trim() : null;
    const endDate: string = srar.endDate ? srar.endDate.trim() : null;

    const sD = AcademicRecordUtil.getSimpleYearFromDate(startDate);
    const eD = AcademicRecordUtil.getSimpleYearFromDate(endDate);

    if (sD === '??' && eD === '??') {
      return '-';
    }

    return sD + ' - ' + eD;

  }

  public static getSimpleYearFromDate(date: string) {
    if (date && date.length > 0) {
      const dateParts = date.split('-');
      if (dateParts[0].length <= 0) {
        dateParts[0] = '??';
      }
      return dateParts[0];
    }
    return '??';
  }

  public static formatSchoolName(school: School) {

    let formatted = '';

    if (school) {

      if (school.name) {
        formatted += school.name.trim();
      }

      if (school.city) {
        formatted += ', ' + school.city;
      }

      if (school.state) {
        formatted += ', ' + school.state;
      } else if (school.highSchoolProvince) {
        formatted += ', ' + school.highSchoolProvince;
      }

      if (school.country) {
        formatted += ', ' + school.country;
      }
    }
    return formatted;
  }

  public static getExtOrgIdLabel(ceeb: string, extOrgId: number): any {
    return extOrgId ? extOrgId : '(' + ceeb + ')';
  }
}
