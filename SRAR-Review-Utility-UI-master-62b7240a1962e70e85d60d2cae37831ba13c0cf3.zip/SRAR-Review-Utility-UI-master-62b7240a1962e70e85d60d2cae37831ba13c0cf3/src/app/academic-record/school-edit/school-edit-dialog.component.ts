import {Component} from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { Srar } from '../../models/Srar';
import { School } from '../../models/School';
export interface SchoolModel {
  srar: Srar;
}
@Component({
    selector: 'app-school-edit-dialog',
    styles: ['.modal-dialog { width: 95%; height: auto; } .modal-body { max-height: 700px; overflow-y: hidden; }'],
    template: `<div class="modal-dialog">
                <div class="modal-content">
                   <div class="modal-header">
                     <button type="button" class="close" (click)="close()" >&times;</button>
                     <h4 class="modal-title">Find School</h4>
                   </div>
                   <div class="modal-body">
                        <app-school-edit [srar]='srar' (onSchoolSelected)="schoolSelected($event)"></app-school-edit>
                   </div>
                   <div class="modal-footer">
                     <button type="button" class="btn btn-default" (click)="close()" >Cancel</button>
                     <button [disabled]="!this.selectedSchool" type="button" class="btn btn-success" (click)="confirm()">Done</button>
                   </div>
                 </div>
              </div>`
})
export class SchoolEditDialogComponent extends DialogComponent<SchoolModel, Srar> implements SchoolModel {
  srar: Srar;

  public selectedSchool: School = null;

  constructor(dialogService: DialogService) {
    super(dialogService);
  }

  schoolSelected(school: School) {
    this.selectedSchool = school;
  }

  confirm() {
    if (this.srar === undefined || this.srar === null) {
      this.srar = new Srar();
    }
    this.srar.school = this.selectedSchool;
    this.srar.ceebCode = this.selectedSchool.code;
    this.srar.externalOrgId = +this.selectedSchool.extOrgId;
    this.result = this.srar;
    this.close();
  }
}
