import { Component, OnInit, ViewChildren, Input, Output, AfterViewInit, EventEmitter, OnDestroy } from '@angular/core';
import { CodeService } from '../../models/CodeService';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Srar } from '../../models/Srar';
import { School } from '../../models/School';
import {AcademicRecordService} from '../academic-record.service';
import {Subscription} from 'rxjs/Subscription';
import {tap, debounceTime} from 'rxjs/operators';
import {AcademicRecordUtil} from '../academic-record.util';

@Component({
  selector: 'app-school-edit',
  templateUrl: './school-edit.component.html',
  styleUrls: ['./school-edit.component.css']
})
export class SchoolEditComponent implements OnInit, OnDestroy, AfterViewInit  {
@ViewChildren('input') vc;

  public getStateOrProvince = AcademicRecordUtil.getStateOrProvinceFromSchool;
  public formatSchool = AcademicRecordUtil.formatSchoolName;

  @Input()
  public srar: Srar;

  @Output()
  public onSchoolSelected: EventEmitter<any> = new EventEmitter<any>();

  public countries: Array<any>;

  public stateOrProvinceList: Array<any>;

  public form: FormGroup;
  public schoolSelected: School = null;
  public searchResults: any = null;
  public isLoading: boolean = null;

  private stateProvinceCountrySub: Subscription = null;


  constructor(private cs: CodeService,
              private fb: FormBuilder,
              private arService: AcademicRecordService) {
      this.isLoading = false;
      this.form = fb.group({
        country: '',
        stateOrProvince: '',
        searchInput: ''
      });

  }
  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }

  ngOnInit() {
    this.countries = this.cs.codes.countryCodes;

    this.onChange();
    this.getStateOrProvinceListByCountrySelection(this.form.get('country').value);
    if (this.srar !== undefined && this.srar !== null) {
      this.searchResults = {};
      this.searchResults.numberOfElements = 1;
      this.searchResults.totalElements = 1;
      this.searchResults.content = [this.srar.school];
      this.schoolSelected = this.srar.school;
      this.onSchoolSelected.emit(this.schoolSelected);
    }
  }

  private onChange() {
    this.stateProvinceCountrySub = this.form.get('country').valueChanges.subscribe(value => {
      this.getStateOrProvinceListByCountrySelection(value);
      this.form.get('stateOrProvince').setValue('');
    });

    this.form.valueChanges
      .pipe(
        tap(() => { this.isLoading = true; this.schoolSelected = null; }),
        debounceTime(1000))
      .subscribe((values) => {
          this.performSearch();
        });

  }

  ngOnDestroy(){
    this.stateProvinceCountrySub.unsubscribe();
  }

  private performSearch() {
    this.isLoading = true;
    const params = {
      country: this.form.get('country').value,
      stateOrProvinceCode: this.form.get('stateOrProvince').value,
      searchInput: this.form.get('searchInput').value
    };
    this.arService.doSchoolSearch(params).subscribe((data: Array<School>) => { this.searchResults = data; this.isLoading = false; });
  }

  public getStateOrProvinceListByCountrySelection(countryCode: string) {
    const res = this.countries.find((el) => {
      return el.countrycodelp === countryCode;
    });
    this.stateOrProvinceList = res ? res.stateOrProvinceList : null;
  }

  public isSchoolSelected(school: School) {
    if (this.schoolSelected) {
      return this.schoolSelected.extOrgId === school.extOrgId;
    }
    return false;
  }

  public selectSchool(event: any , school: School) {
    if (this.isSchoolSelected(school)) {
      this.schoolSelected = null;
    } else {
      this.schoolSelected = school;
    }
    this.onSchoolSelected.emit(this.schoolSelected);
  }
}
