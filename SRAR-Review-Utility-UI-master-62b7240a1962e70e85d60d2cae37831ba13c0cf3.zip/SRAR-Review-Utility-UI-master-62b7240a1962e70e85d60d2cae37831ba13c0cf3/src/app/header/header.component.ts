import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Config } from '../config.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // public logOutUrl = null;
  title: String = "SRAR Review Utility";
  user: String = null;

  constructor(private router: Router, private config: Config) {
  }

  ngOnInit() {
    this.user = this.config.getUser();
  }

  public logOut() {
    window.location.href="https://webaccess.psu.edu/cgi-bin/logout";
  }
}
