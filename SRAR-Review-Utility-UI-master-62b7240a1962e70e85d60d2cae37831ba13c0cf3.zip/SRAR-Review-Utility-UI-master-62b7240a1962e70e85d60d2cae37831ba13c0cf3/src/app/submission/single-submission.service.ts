import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import {Config} from '../config.service';
import {Srar} from '../models/Srar';

import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {tap, finalize} from 'rxjs/operators';

@Injectable()
export class SingleSubmissionService {

  private readonly submissionsUrl = null;

  private _submission: any = null;
  private submissionUpdatedSubj: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  public submissionUpdated: Observable<any> = null;

  private submissionReloadLockSubj: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public submissionReloadLock: Observable<boolean> = null;

  constructor(private http: HttpClient, private config: Config) {

    this.submissionsUrl = config.getApiUrl() + 'submissions/';
    this.submissionUpdated = this.submissionUpdatedSubj.asObservable();
    this.submissionReloadLock = this.submissionReloadLockSubj.asObservable();
  }

  public lockSubmission() {
    this.submissionReloadLockSubj.next(true);
  }

  public unlockSubmission() {
    this.submissionReloadLockSubj.next(false);
  }

  public get submission() {
    return this._submission;
  }

  private onUpdateSubmission(submission: any) {
    this._submission = submission;
    this.submissionUpdatedSubj.next(this._submission);
  }

  public httpDoesSubmissionExist(psuId: String) {
    return this.http
      .get<boolean>(this.submissionsUrl + psuId + '/exists');
  }

  public refetchSubmission(): void {
    if (this.submission !== undefined && this.submission !== null) {
      this.fetchSubmissionByPsuId(this.submission.psuId).subscribe();
    }
    return null;
  }

  public fetchSubmissionByPsuId(psuId: String): Observable<any> {
    return this.http
      .get(this.submissionsUrl + psuId)
      .pipe(
        tap((data) => {
          this.onUpdateSubmission(data);
        })
      );
  }

  public updateGraduationYear(psuId: string, graduationYear: string): Observable<Array<Srar>> {

    const url = this.submissionsUrl + psuId + '/updateGraduationYear';

    return this.http.post<Array<Srar>>(url, graduationYear)
      .pipe(
        tap((data) => this.onUpdateSubmission(data))
      );
  }

  private doStatusChangeHttp(url: string) {
    this.lockSubmission();
    return this.http.post(url, {})
      .pipe(
        tap(data => this.onUpdateSubmission(data)),
        finalize(() => this.unlockSubmission())
      );
  }

  public sendToLP(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/sendToLP';
    this.doStatusChangeHttp(url).subscribe();
  }

  public returnToStudent(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/returnToStudent';
    this.doStatusChangeHttp(url).subscribe((data: any) => {
      if (!data.returnedToStudent) {
        alert('Error returning srar to student!');
      }
    });
  }

  public clearStatus(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/clearStatus';
    this.doStatusChangeHttp(url).subscribe();
  }

  public reOpenSrar(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/reOpenSrar';
    this.doStatusChangeHttp(url).subscribe();
  }

  public populateDummyDate(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/populateDummyDate';
    this.doStatusChangeHttp(url).subscribe();
  }

  public deactivate(submission: any) {
    const url = this.submissionsUrl + submission.psuId + '/deactivate';
    this.doStatusChangeHttp(url).subscribe();
  }
}
