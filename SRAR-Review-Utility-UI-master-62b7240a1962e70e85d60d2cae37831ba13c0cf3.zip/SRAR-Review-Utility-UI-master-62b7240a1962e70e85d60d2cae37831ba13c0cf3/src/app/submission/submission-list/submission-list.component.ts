import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit} from '@angular/core';
import { SearchSubmissionService } from '../search-submission.service';
import { SubmissionSearchCache, PageConfig, SortConfig } from '../../models/SearchCriteria';
import { CodeService } from '../../models/CodeService';
import { SpecialAcademicProgramCode } from '../../models/Codes';
import {ColumnSortedEvent, SortService} from '../../sort/sort.service';

@Component({
  selector: 'app-submission-list',
  templateUrl: './submission-list.component.html',
  styleUrls: ['./submission-list.component.css'],
  providers: []
})

export class SubmissionListComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('psuIdInput') psuIdInput;

  public loading = false;

  public campusCodes: Array<any>;
  public internationalCountryCodesChinaFirst: Array<any>;
  public specialAcademicProgramCodes: Array<SpecialAcademicProgramCode>;

  public criteria: SubmissionSearchCache;

  public searchTextValue: string;
   public searchFirstNameValue: string;
   public searchMiddleNameValue: string;
   public searchLastNameValue: string;

  constructor(
    private codeService: CodeService,
    private searchSubmissionService: SearchSubmissionService) {
}

  ngAfterViewInit() {
    this.psuIdInput.nativeElement.focus();
  }

  ngOnInit() {

    if (this.searchSubmissionService.cache) {
      this.criteria = this.searchSubmissionService.getCopyOfCacheCriteria();
    } else {
      this.criteria = new SubmissionSearchCache();
    }

    this.campusCodes = this.codeService.codes.campusCodes;
    this.internationalCountryCodesChinaFirst = this.sortInternationalChinaFirst(this.codeService.codes.countryCodes);
    this.specialAcademicProgramCodes = this.codeService.codes.specialAcademicProgramCodes;

    this.performSearch(true);
    this.clearSearchFields();

  }

    ngOnDestroy() {}

  private sortInternationalChinaFirst(_codes: Array<any>): Array<any> {

    const codes = Object.assign([], _codes);

    const chn = 'CHN';
    const usa = 'USA';
    let chinaIdx = -1;
    let usaIdx = -1;
    let chinaEl = null;

    for (let i = 0; i < codes.length; i++) {
      const curr = codes[i];
      if (curr.countrycodelp === chn) {
        chinaIdx = i;
      }
      if (curr.countrycodelp === usa) {
        usaIdx = i;
      }
    }

    if (chinaIdx >= 0) {
      chinaEl = codes.splice(chinaIdx, 1);
      codes.splice(0, 0, chinaEl[0]);
    }

    if (usaIdx >= 0) {
      codes.splice(usaIdx, 1);
    }

    return codes;
  }

  public onChangeClear(newVal: any) {
   const currVal = this.criteria.search.searchType;
   if (newVal !== currVal && (newVal === 1 || currVal === 1)) {
     this.clearSearchFields();
   }
   this.criteria.search.searchType = newVal;
 }

 private clearSearchFields() {
   this.criteria.search.searchTextValue = null;
   this.criteria.search.searchFirstNameValue  = null;
   this.criteria.search.searchMiddleNameValue = null;
   this.criteria.search.searchLastNameValue  = null;
 }

  private performSearch(showLoading?: boolean) {

    // Perform the search
    this.loading = showLoading || false;
    this.searchSubmissionService.loadSubmissions(this.criteria)
    .subscribe(data => {
      this.criteria.response = data;
      this.criteria.pageConfig.totalItems = this.criteria.response.totalElements;
      this.loading = false;
   });
  }

  public onSortChange(sortChange: ColumnSortedEvent) {
      this.criteria.pageConfig.currentPage = 1;
      const timer = setTimeout(() => {
        this.loading = true;
      }, 500);
      this.searchSubmissionService.loadSubmissionsSort(this.criteria.sortConfig)
      .subscribe(data => {
        clearTimeout(timer);
        this.loading = false;
        this.criteria.response = data;
      });
  }

  public onResetClicked() {
    const newCache = new SubmissionSearchCache();
    newCache.response = this.criteria.response;
    this.criteria = newCache;
    this.performSearch(true);
  }

  public onSearchClicked() {

    this.criteria.pageConfig.currentPage = 1;
    this.performSearch(true);
  }

  public onPageChange(newPage?: number) {
    this.criteria.search = this.searchSubmissionService.getCopyOfCacheCriteria().search;
    this.criteria.pageConfig.currentPage = newPage;
    const timer = setTimeout(() => {
      this.loading = true;
    }, 500);

    this.searchSubmissionService.loadSubmissionsPage(this.criteria.pageConfig)
    .subscribe(data => {
      clearTimeout(timer);
      this.loading = false;
      this.criteria.response = data;
   });
  }

  public onPageEnterClicked(inputEl: any, lastPage: number) {

      const inputVal = inputEl.value;

      let num = Number(inputVal);
      if (Number.isNaN(num)) {
        num = 0;
      }

      if (num > 0 && num <= lastPage) {
        this.onPageChange(num);
        return true;
      }
      inputEl.value = this.criteria.pageConfig.currentPage;
      return false;
  }

  public onRefreshClicked() {
    this.criteria.search = this.searchSubmissionService.getCopyOfCacheCriteria().search;
    this.performSearch(true);
  }

  public checkSpecialPlanInput() {
    if (!this.criteria.search.submittedApp) {
      this.criteria.search.specialAcademicProgramCheckbox = false;
    }
  }

  public onSchoolLocationChange() {
    this.criteria.search.schoolLocationAdditional = '';
    this.onSchoolLocationAdditionalChange();
  }

  public onSchoolLocationAdditionalChange() {
    if (this.criteria.search.schoolLocationAdditional === '') {
      this.criteria.search.schoolLocationAdditionalExclude = false;
    }
  }
}
