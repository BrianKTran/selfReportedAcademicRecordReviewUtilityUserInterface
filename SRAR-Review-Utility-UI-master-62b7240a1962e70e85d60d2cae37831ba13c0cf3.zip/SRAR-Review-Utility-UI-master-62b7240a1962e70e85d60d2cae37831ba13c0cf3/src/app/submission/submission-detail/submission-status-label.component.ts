import { Component, Input, OnChanges } from '@angular/core';
import { SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-submission-status-label',
  template: `<span [ngClass]="status.statusClass" style="margin-right: 5px;">{{status.statusLabel}}</span>`
})

export class SubmissionStatusLabelComponent implements OnChanges {

  @Input('status')
  private _status: string;
  public status: {statusClass: string, statusLabel: string} = null;

  constructor() {}

  ngOnChanges(changes: SimpleChanges) {
    this.setStatus();
  }

  private setStatus() {
    switch (this._status) {
      case 'inactive': {
        this.status = {
          statusClass: 'label label-default',
          statusLabel: 'Inactive'
        };
        break;
      }
      case 'pending': {
        this.status = {
          statusClass: 'label label-primary',
          statusLabel: 'Pending Review'
        };
        break;
      }
      case 'approved': {
        this.status = {
          statusClass: 'label label-info',
          statusLabel: 'Approved'
        };
        break;
      }
      case 'sent_to_lionpath': {
        this.status = {
          statusClass: 'label label-success',
          statusLabel: 'Sent to Lionpath'
        };
        break;
      }
      case 'returned_to_student': {
        this.status = {
          statusClass: 'label label-danger',
          statusLabel: 'Returned to Student'
        };
        break;
      }
      case 'returned_to_student_pending': {
        this.status = {
          statusClass: 'label label-danger',
          statusLabel: 'Returned to Student'
        };
        break;
      }
      default: {
        this.status = {
          statusClass: 'label label-warning',
          statusLabel: 'Unknown'
        };
      }
    }
  }

}
