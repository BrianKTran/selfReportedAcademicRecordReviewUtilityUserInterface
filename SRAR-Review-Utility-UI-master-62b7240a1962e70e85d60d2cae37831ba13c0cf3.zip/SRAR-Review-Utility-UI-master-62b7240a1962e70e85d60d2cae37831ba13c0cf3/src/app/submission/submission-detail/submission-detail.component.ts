import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SingleSubmissionService } from '../single-submission.service';
import {AcademicRecordService} from '../../academic-record/academic-record.service';
import {CourseService} from '../../course/course.service';
import {Subscription} from 'rxjs/Subscription';
import {forkJoin as ForkJoin} from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-submission-detail',
  templateUrl: './submission-detail.component.html',
  styleUrls: ['./submission-detail.component.css']
})
export class SubmissionDetailComponent implements OnInit, OnDestroy {

  private idSub: Subscription = null;
  private submissionReloadingSub: Subscription = null;

  public psuId = null;
  public hasSubmission = false;
  public isInitialLoading = true;
  public isReloading = false;

  constructor(private submissionService: SingleSubmissionService,
              private arService: AcademicRecordService,
              private courseService: CourseService,
              private route: ActivatedRoute) {}

  ngOnInit() {
    this.idSub = this.route.params.subscribe(params => {
      this.psuId = +params['psuId'];
      this.fetchAllData();
    });

    this.submissionReloadingSub = this.submissionService.submissionReloadLock
      .subscribe(locked => this.isReloading = locked);
  }

  private fetchAllData() {
    const subSub = this.submissionService.httpDoesSubmissionExist(this.psuId)
      .subscribe((submissionExists) => {
        if (!submissionExists) {
          this.hasSubmission = false;
          this.isInitialLoading = false;
          subSub.unsubscribe();
          return;
        }
        // If we found a submission, fetch the rest of the relevant data
        this.hasSubmission = true;
        const forkSub = ForkJoin(
          this.submissionService.fetchSubmissionByPsuId(this.psuId),
          this.courseService.fetchCoursesByPsuId(this.psuId),
          this.arService.fetchSrarsByPsuId(this.psuId))
          .subscribe(() => {
            this.isInitialLoading = false;
            subSub.unsubscribe();
            forkSub.unsubscribe();
          });
      });
  }

  ngOnDestroy() {
    this.idSub.unsubscribe();
    this.submissionReloadingSub.unsubscribe();
  }



}
