import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuditLogComponent} from '../../../dialog/audit-dialog.component';
import {AutoApprovalFailureDialogComponent} from '../../../dialog/auto-approval-failure-dialog.component';
import {ConfirmComponent} from '../../../dialog/confirm-dialog.component';
import {SpecialAcademicProgramCode} from '../../../models/Codes';
import {Config} from '../../../config.service';
import {AcademicRecordService} from '../../../academic-record/academic-record.service';
import {CourseService} from '../../../course/course.service';
import {SingleSubmissionService} from '../../single-submission.service';
import {DialogService} from 'ng2-bootstrap-modal';
import {CodeService} from '../../../models/CodeService';
import {ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs/Subscription';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-submission-info',
  templateUrl: './submission-info.component.html',
  styleUrls: ['./submission-info.component.css']
})
export class SubmissionInfoComponent implements OnInit, OnDestroy {

  private submissionSub: Subscription = null;

  public submission = null;
  public recordType = '';
  public isProduction = false;
  public isSpecialPlan = false;
  public specialPlanValue = '-';
  public isLessThanReqCredits: boolean;
  private specialAcademicProgramCodes: Array<SpecialAcademicProgramCode>;

  public isLocked: boolean;
  public form: FormGroup;
  public editMode = false;
  public isSaving = false;
  private isLoading = true;
  public pdfUrl: string;

  constructor(
    private submissionService: SingleSubmissionService,
    private arService: AcademicRecordService,
    private courseService: CourseService,
    private route: ActivatedRoute,
    private ds: DialogService,
    private config: Config,
    private codeService: CodeService,
    private fb: FormBuilder) {
      this.form = fb.group({
        graduationYear: [null, [Validators.required, Validators.pattern('^[0-9]{4}-[0-9]{2}')]],
      });
  }

  ngOnInit() {
    this.isProduction = this.config.isProduction();
    this.submissionSub = this.submissionService.submissionUpdated.subscribe((data: any) => {
      this.submission = data;
      this.onInit();
    });
  }

  ngOnDestroy() {
    this.submissionSub.unsubscribe();
  }

  private onInit() {
    this.pdfUrl = this.config.getApiUrl() + `submissions/${this.submission.psuId}/pdf`;
    this.isLocked = this.submissionService.submission.isLocked;
    this.specialAcademicProgramCodes = this.codeService.codes.specialAcademicProgramCodes;
    this.isSpecialPlan = this.getIsSpecialPlan();
    if (this.isSpecialPlan) {
      this.specialPlanValue = this.getSpecialPlanValue();
    }

    this.isLessThanReqCredits = this.submission.totalCreditsCompleted <= 17;
  }

  public onEditEnable() {
    this.editMode = true;
  }

public onEditSaveClicked() {
  this.isSaving = true;
  this.submissionService.updateGraduationYear(this.submission.psuId, this.form.value.graduationYear)
    .subscribe(() => {
      this.isSaving = false;
      this.editMode = false;
    });
}

onLoadDataClicked() {
    return null;
}

  public onEditCancelClicked() {
    this.editMode = false;
  }



  onClickAuditLog() {
    const disposable = this.ds.addDialog(AuditLogComponent, {
      psuId: this.submission.psuId})
      .subscribe(() => {
        disposable.unsubscribe();
      });
  }

  onClickAutoApprovalFailures() {
    const disposable = this.ds.addDialog(AutoApprovalFailureDialogComponent, {
      autoApprovalFailures: this.submission.autoApprovalFailures})
      .subscribe(() => {
        disposable.unsubscribe();
      });
  }

  onClickDeactivateStatus() {

    const disposable = this.ds.addDialog(ConfirmComponent, {
      title: 'Deactivate Status',
      type: 'deactivate',
      message: 'Are you sure you want to deactivate this record?'})
      .subscribe((isConfirmed) => {
        // We get dialog result
        if (isConfirmed) {
          this.submissionService.deactivate(this.submission);
          // Ok clicked
        } else {
          // Cancel clicked
        }
        disposable.unsubscribe();
      });
  }


  onClickSendToLP() {

    const disposable = this.ds.addDialog(ConfirmComponent, {
      title: 'Confirm Send',
      type: 'send',
      message: 'Are you sure you want to send this record to LionPath?'})
      .subscribe((isConfirmed) => {
        // We get dialog result
        if (isConfirmed) {
          this.submissionService.sendToLP(this.submission);
          // Ok clicked
        } else {
          // Cancel clicked
        }
        disposable.unsubscribe();
      });
  }

  onClickReturnToStudent() {


    const disposable = this.ds.addDialog(ConfirmComponent, {
      title: 'Confirm Return',
      type: 'return',
      message: 'Are you sure you want to return this record to the student?'})
      .subscribe((isConfirmed) => {
        // We get dialog result
        if (isConfirmed) {
          this.submissionService.returnToStudent(this.submission);
        } else {
        }
        disposable.unsubscribe();
      });

  }

  onClickClearStatus() {
    this.submissionService.clearStatus(this.submission);
  }

  onClickReOpenSrar() {
    const disposable = this.ds.addDialog(ConfirmComponent, {
      title: 'Confirm Re-Open Srar',
      type: 'reopen',
      message: 'Are you sure you want to reopen this SRAR?'})
      .subscribe((isConfirmed) => {
        // We get dialog result
        if (isConfirmed) {
          this.submissionService.reOpenSrar(this.submission);
        } else {
        }
        disposable.unsubscribe();
      });

  }

  onClickPopulateDummyDate() {
    this.submissionService.populateDummyDate(this.submission);
  }

  public getAcademicStatus() {
    if (!this.submission.student || !this.submission.student.webapp || !this.submission.student.webapp.academicStatus) {
      return '-';
    }

    const value = this.submission.student.webapp.academicStatus;
    let retVal = '-';

    switch (value) {
      case 1: {
        retVal = 'Early Graduate';
        break;
      }
      case 2: {
        retVal = 'High School Senior';
        break;
      }
      case 3: {
        retVal = 'High School Graduate';
        break;
      }
      case 4: {
        retVal = 'GED Recipient';
        break;
      }
      default: {
        break;
      }
    }
    return retVal;
  }

  public getIsSpecialPlan(): boolean {

    let isSpecial = false;

    if (this.specialAcademicProgramCodes
      && this.submission.student
      && this.submission.student.webapp
      && this.submission.student.webapp.programOfStudy) {
      const program = this.submission.student.webapp.programOfStudy.commonyear;
      for (let i = 0; i < this.specialAcademicProgramCodes.length; i++) {
        const codeObj: SpecialAcademicProgramCode = this.specialAcademicProgramCodes[i];
        if (codeObj.code === program) {
          isSpecial = true;
          break;
        }
      }
    }
    return isSpecial;
  }

  public getSpecialPlanValue(): string {
    let retVal = '-';
    const program = this.submission.student.webapp.programOfStudy.commonyear;
    for (let i = 0; i < this.specialAcademicProgramCodes.length; i++) {
      const codeObj: SpecialAcademicProgramCode = this.specialAcademicProgramCodes[i];
      if (codeObj.code === program) {
        retVal = codeObj.value;
        break;
      }
    }
    return retVal;
  }

}
