import {Injectable} from '@angular/core';
import {HttpClient, HttpParams, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import {Config} from '../config.service';
import {SubmissionSearchCache, PageConfig, SortConfig} from '../models/SearchCriteria';
import {map, tap, timeout} from 'rxjs/operators';

@Injectable()
export class SearchSubmissionService {

  private submissionsUrl = null;

  public cache: SubmissionSearchCache;

  constructor(private http: HttpClient, private config: Config) {

    this.submissionsUrl = config.getApiUrl() + 'submissions/';

    this.cache = new SubmissionSearchCache();
  }

  public loadSubmissions(criteria: SubmissionSearchCache, isPageChange?: boolean): Observable<any> {

    this.copyCriteriaToCache(criteria);

    const queryMap: any = criteria.getQueryObject();

    if (isPageChange) {
      queryMap['pageChange'] = 'true';
    }

    const params = new HttpParams({fromObject: queryMap});

    return this.http
      .get/*TODO: Add response body type here*/(this.submissionsUrl, {params: params})
      .pipe(
        timeout(120000),
        tap((data) => {
          this.cache.response = data;
        })
      );
  }

  public loadSubmissionsPage(pageInfo: PageConfig): Observable<any> {
    const page: PageConfig = this.cache.pageConfig;

    page.currentPage = pageInfo.currentPage;
    page.itemsPerPage = pageInfo.itemsPerPage;
    page.totalItems = pageInfo.totalItems;
    return this.loadSubmissions(this.cache, true);
  }

  public loadSubmissionsSort(sortInfo: SortConfig): Observable<any> {
    const sort: SortConfig = this.cache.sortConfig;
    const page: PageConfig = this.cache.pageConfig;

    sort.sortBy = sortInfo.sortBy;
    sort.sortOrder = sortInfo.sortOrder;
    page.currentPage = 1;

    return this.loadSubmissions(this.cache, true);
  }

  public getCopyOfCacheCriteria(): SubmissionSearchCache {
    const cacheCopy = new SubmissionSearchCache();
    cacheCopy.pageConfig = Object.assign({}, this.cache.pageConfig);
    cacheCopy.search = Object.assign({}, this.cache.search);
    cacheCopy.sortConfig = Object.assign({}, this.cache.sortConfig);
    cacheCopy.response = this.cache.response;

    return cacheCopy;
  }

  public copyCriteriaToCache(criteria: SubmissionSearchCache) {
    this.cache.pageConfig = Object.assign({}, criteria.pageConfig);
    this.cache.search = Object.assign({}, criteria.search);
    this.cache.sortConfig = Object.assign({}, criteria.sortConfig);
  }

}
