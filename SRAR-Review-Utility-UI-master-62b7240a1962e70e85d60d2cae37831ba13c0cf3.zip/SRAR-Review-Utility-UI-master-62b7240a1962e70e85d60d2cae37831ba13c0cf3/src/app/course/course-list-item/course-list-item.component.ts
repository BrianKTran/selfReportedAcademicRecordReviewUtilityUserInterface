import {Component, Input, Output, OnInit, EventEmitter, OnDestroy, HostBinding} from '@angular/core';
import {SingleSubmissionService} from '../../submission/single-submission.service';
import {VendorBundle} from '../../models/Codes';
import {DialogService} from 'ng2-bootstrap-modal';
import {ConfirmComponent} from '../../dialog/confirm-dialog.component';
import {ErrorDialogComponent} from '../../dialog/error-dialog.component';
import {Course} from '../../models/Course';
import {CourseService} from '../course.service';
import {Srar} from '../../models/Srar';
import {AcademicRecordService} from '../../academic-record/academic-record.service';
import {Subscription} from 'rxjs/Subscription';
import {AcademicRecordUtil} from '../../academic-record/academic-record.util';
import {CodeService} from '../../models/CodeService';

@Component({
  selector: 'tr[course]',
  templateUrl: './course-list-item.component.html',
  styleUrls: ['./course-list-item.component.css']
})
export class CourseListItemComponent implements OnInit, OnDestroy {
  private submissionServiceSub: Subscription = null;
  private courseListItemSub: Subscription = null;

  @Input()
  public course: Course;

  public isLocked: boolean;
  public courseCopy: Course = null;

  @HostBinding('class.selected-color')
  public editMode = false;

  public codes: VendorBundle;

  public isCourseZeroCredit: boolean;
  public isSaving = false;

  public srars: Array<Srar> = null;
  public getExtOrgIdLabel = AcademicRecordUtil.getExtOrgIdLabel;

  @Output()
  public onUpdated: EventEmitter<Course> = new EventEmitter<Course>();

  @Output()
  public onEditCancelled: EventEmitter<Course> = new EventEmitter<Course>();

  constructor(private courseService: CourseService,
              private codeService: CodeService,
              private academicRecordService: AcademicRecordService,
              private submissionService: SingleSubmissionService,
              private ds: DialogService) {


  }

  public ngOnInit() {

    this.codes = this.codeService.codes.lionpathCodes;

    this.submissionServiceSub = this.submissionService.submissionUpdated.subscribe(data => {
      this.setMetaData();
    });

    this.courseListItemSub = this.academicRecordService.srarsUpdated.subscribe((srars: Array<Srar>) => {
      this.srars = srars;
      const s: Srar = srars.find(srar => srar.recordId === this.course.recordId);
      this.course.extOrgId = s ? s.externalOrgId : null;
      this.course.ceebCode = s ? s.ceebCode : null;
    });

    if (this.course.courseId === undefined || this.course.courseId === null) {
      this.onEditEnable();
    } else {
      this.checkCreditFlag();
    }

  }

  ngOnDestroy() {
    this.submissionServiceSub.unsubscribe();
    this.courseListItemSub.unsubscribe();
  }

  private setMetaData() {
    this.isLocked = this.submissionService.submission.isLocked;
  }

  public checkCreditFlag() {

    const subj = this.course.courseSubjectAreaCode;

    if (this.course.sessionAcademicYearCode === '12' && (
      subj === 'English' ||
      subj === 'EN' ||
      subj === 'Mathematics' ||
      subj === 'MT' ||
      subj === 'Science' ||
      subj === 'NS' ||
      subj === 'Social Science' ||
      subj === 'SS' ||
      subj === 'Other Language' ||
      subj === 'FL' ||
      subj === 'Technical' ||
      subj === 'CS' ||
      subj === 'BS')) {
      this.isCourseZeroCredit = !this.course.courseCreditValue ||
        this.course.courseCreditValue === '0';
    }
  }

  public onDeleteClicked() {

    const disposable = this.ds.addDialog(ConfirmComponent, {
      title: 'Confirm Delete',
      type: 'delete',
      message: 'Are you sure you want to delete this record?'
    })
      .subscribe((isConfirmed) => {
        // We get dialog result
        if (isConfirmed) {
          this.courseService.delete(this.course.courseId).subscribe();
          // Ok clicked
        } else {
          // Cancel clicked
        }
        disposable.unsubscribe();
      });
  }

  public onEditSaveClicked() {

    const errors: Array<string> = this.checkForErrors(this.courseCopy);

    if (errors && errors.length > 0) {
      const disposable = this.ds.addDialog(ErrorDialogComponent, {
        title: 'Course Errors',
        message: 'Cannot save course. Please correct following errors and try again',
        errors: errors
      })
        .subscribe(() => {
          disposable.unsubscribe();
        });
      return false;
    }
    this.course = this.courseCopy;
    this.isSaving = true;
    if (this.course.courseId !== undefined && this.course.courseId !== null) {
      this.doCourseUpdate();
    } else {
      this.doNewCourseAdd();
    }

  }

  private doNewCourseAdd() {
    this.onUpdated.emit(this.course);
  }

  private doCourseUpdate() {
    this.courseService.update(this.course).subscribe(() => {
      this.isSaving = false;
      this.editMode = false;
    });
  }

  private checkForErrors(course: Course): Array<string> {

    const errors = [];

    if (!course.courseSubjectAreaCode) {
      errors.push('Subject Code not selected');

    }
    if (!course.courseNumber) {
      errors.push('Course Number not selected');

    }
    if (!course.courseLevel) {
      errors.push('Course Level not selected');

    }
    if (!course.sessionAcademicYearCode) {
      errors.push('Year Code not selected');

    }
    if (!course.sessionType) {
      errors.push('Session Type not selected');

    }

    const courseCreditVal = String(course.courseCreditValue).trim();
    if (!courseCreditVal || courseCreditVal.length <= 0) {
      errors.push('Credit value not entered');
    } else {
      const num = Number(course.courseCreditValue);
      if (Number.isNaN(num)) {
        errors.push('Credit value not valid');
      } else if (num < 0) {
        errors.push('Credits can\'t be less than 0');
      }
    }

    if (!course.courseAcademicGrade) {
      errors.push('Grade not entered');

    }
    return errors;
  }

  public onEditCancelClicked() {
    this.courseCopy = null;
    this.editMode = false;
    this.onEditCancelled.emit(null);
  }

  public onEditEnable() {
    const courseOriginal = Object.assign({}, this.course);
    this.courseCopy = courseOriginal;
    this.editMode = true;
  }

  public onCourseNumberChange(newValue) {
    const codeMatch = this.codes.courseNumberCodes.find((cd) => cd.courseCode === newValue);
    if (codeMatch) {
      this.courseCopy.courseTitle = codeMatch.courseName;
    }
  }

}
