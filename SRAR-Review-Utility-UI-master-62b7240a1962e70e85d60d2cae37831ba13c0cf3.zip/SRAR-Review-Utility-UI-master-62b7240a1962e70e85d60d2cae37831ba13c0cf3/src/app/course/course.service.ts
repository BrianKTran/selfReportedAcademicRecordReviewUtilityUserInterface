import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import {Config} from '../config.service';
import {Course} from '../models/Course';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {SingleSubmissionService} from '../submission/single-submission.service';
import {tap} from 'rxjs/operators';

@Injectable()
export class CourseService {

  private readonly baseSubmissionUrl = null;
  private readonly baseCourseUrl = null;

  private _courses: Array<Course> = null;
  public coursesUpdatedSubj: BehaviorSubject<Array<Course>> = new BehaviorSubject<Array<Course>>(null);
  public coursesUpdated = this.coursesUpdatedSubj.asObservable();


  constructor(private http: HttpClient,
              private config: Config,
              private submissionService: SingleSubmissionService) {

    this.baseSubmissionUrl = config.getApiUrl() + 'submissions/';
    this.baseCourseUrl = config.getApiUrl() + 'courses/';

  }

  private onUpdateCourses(courses: Array<Course>) {
    this._courses = courses;
    this.coursesUpdatedSubj.next(this._courses);
  }

  public get courses() {
    return this._courses;
  }

  public fetchCoursesForCurrentSubmission(): Observable<any> {
    return this.fetchCoursesByPsuId(this.submissionService.submission.psuId);
  }

  public fetchCoursesByPsuId(psuId: string): Observable<any> {
    return this.http
      .get(this.baseSubmissionUrl + psuId + '/courses')
      .pipe(
        tap((data) => {
          this.onUpdateCourses(data);
        })
      );
  }

  public create(course: Course): Observable<any> {

    const url: string = this.baseSubmissionUrl + course.psuId + '/srars/' + course.recordId + '/courses';

    return this.http.post(url, course)
      .pipe(
        tap(data => {
          this._courses.push(data);
          this.onUpdateCourses(this._courses);
          this.submissionService.refetchSubmission();
        })
      );
  }

  public update(course: Course): Observable<any> {
    const courseId = course.courseId;
    const url: string = this.baseCourseUrl + courseId;

    return this.http.put(url, course)
      .pipe(
        tap(data => {
          const idx = this._courses.findIndex(el => el.courseId === data.courseId);
          if (idx >= 0) {
            this._courses[idx] = data;
            this.onUpdateCourses(this._courses);
            this.submissionService.refetchSubmission();
          }
        })
      );
  }

  public delete(courseId): Observable<any> {
    const url: string = this.baseCourseUrl + courseId;

    return this.http.delete(url)
      .pipe(
        tap(() => {
          const idx = this._courses.findIndex(el => el.courseId === courseId);
          if (idx >= 0) {
            this._courses.splice(idx, 1);
            this.onUpdateCourses(this._courses);
            this.submissionService.refetchSubmission();
          }
        })
      );
  }
}
