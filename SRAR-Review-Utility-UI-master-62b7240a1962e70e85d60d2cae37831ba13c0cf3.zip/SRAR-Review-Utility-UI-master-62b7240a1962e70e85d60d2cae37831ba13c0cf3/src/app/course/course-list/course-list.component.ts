import {Component, OnInit, OnDestroy} from '@angular/core';
import {SingleSubmissionService} from '../../submission/single-submission.service';
import {Course} from '../../models/Course';
import {CourseService} from '../course.service';
import {Subscription} from 'rxjs/Subscription';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit, OnDestroy {
  private submissionSub: Subscription = null;
  private courseListSub: Subscription = null;

  public courses: Array<Course>;

  public isLocked = false;

  public sortBy = 'courseSubjectAreaCode';
  public sortOrder = 'asc';

  public newCourse = null;

  constructor(private courseService: CourseService,
              private submissionService: SingleSubmissionService) {
  }

  ngOnInit() {
    this.submissionSub = this.submissionService.submissionUpdated.subscribe((s) => {
      this.setLockedStatus();
    });

    this.courseListSub = this.courseService.coursesUpdated
      .subscribe((courses: Array<Course>) => {
        this.courses = courses;
      });
  }

  ngOnDestroy() {
    this.courseListSub.unsubscribe();
    this.submissionSub.unsubscribe();
  }

  private setLockedStatus() {
    this.isLocked = this.submissionService.submission.isLocked;
  }

  public onAddNewCourseClicked() {
    if (this.newCourse != null) {
      return;
    }

    const recordType = this.submissionService.submission.recordType;
    const starsOrCoalitionId = this.submissionService.submission.dataSourceRecordId;

    this.newCourse = new Course();
    if (recordType === 'STARS') {
      this.newCourse.starsId = starsOrCoalitionId;
    } else {
      this.newCourse.coalitionId = starsOrCoalitionId;
    }
  }

  public onNewCourseSaved(newCourse) {
    newCourse.psuId = this.submissionService.submission.psuId;
    const sub = this.courseService.create(newCourse).subscribe((res) => {
      sub.unsubscribe();
      this.newCourse = null;
    });
  }

  public onNewCourseCancelled() {
    this.newCourse = null;
  }
}
