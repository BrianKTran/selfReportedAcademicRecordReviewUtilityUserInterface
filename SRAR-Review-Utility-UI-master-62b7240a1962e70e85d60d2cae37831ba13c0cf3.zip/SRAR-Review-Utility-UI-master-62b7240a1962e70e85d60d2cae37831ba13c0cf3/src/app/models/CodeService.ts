import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { CodeBundle } from '../models/Codes';


@Injectable()
export class CodeService {

  private _codes: CodeBundle = null;

  constructor(private http: HttpClient) {
  }

  public init(apiUrl: string): Promise<CodeBundle> {
    const codesUrl = apiUrl + 'codes';
    return this.doHttpRequest(codesUrl).toPromise().then((value) => {
      this._codes = new CodeBundle(value);
      return this._codes;
    });
  }

  private doHttpRequest(url: string): Observable<CodeBundle> {
    return this.http
      .get<CodeBundle>(url);
  }

  public get codes(): CodeBundle {
    return this._codes;
  }

}
