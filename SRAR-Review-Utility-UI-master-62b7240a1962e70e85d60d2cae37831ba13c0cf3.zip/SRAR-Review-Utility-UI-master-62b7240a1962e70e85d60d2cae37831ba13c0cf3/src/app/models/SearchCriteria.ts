import { HttpParams } from '@angular/common/http';
import { PaginationInstance } from 'ngx-pagination';

export enum SearchType {
  PSU_ID,
  STUDENT_NAME,
  SCHOOL_NAME,
  CEEB_CODE,

}

export class SortConfig {
  public sortBy: string;
  public sortOrder: string;

  constructor() {
    this.sortBy = 'lpNotifiedOfArrival';
    this.sortOrder = 'asc';
  }
}

export class PageConfig implements PaginationInstance {

  public itemsPerPage: number;
  public currentPage: number;
  public totalItems?: number;

  constructor() {
    this.itemsPerPage = 10;
    this.currentPage = 1;
  }
}

export class SearchCriteria {

  public searchType: SearchType;
  public searchTextValue: string;
  public searchFirstNameValue: string;
  public searchMiddleNameValue: string;
  public searchLastNameValue: string;
  public fromDateCreated: any;
  public toDateCreated: any;
  public status: string;
  public schoolLocation: string;
  public schoolLocationAdditional: string;
  public schoolLocationAdditionalExclude: boolean;
  public submittedApp: boolean;
  public campusSelection: string;
  public sourceOfRecord: string;
  public decileRankUsed: string;
  public citizenship: string;
  public specialAcademicProgramCheckbox: boolean;
  public specialAcademicProgram: string;
  public startDate: any;
  public endDate: any;

  constructor() {
    this.searchType = SearchType.PSU_ID;
    this.searchTextValue = '';
    this.searchFirstNameValue = '';
    this.searchMiddleNameValue = '';
    this.searchLastNameValue = '';
    this.fromDateCreated = null;
    this.toDateCreated = null;
    this.status = 'pending';
    this.schoolLocation = '';
    this.schoolLocationAdditional = '';
    this.schoolLocationAdditionalExclude = false;
    this.sourceOfRecord = '';
    this.decileRankUsed = '';
    this.citizenship = '';
    this.submittedApp = true;
    this.campusSelection = 'ANY';
    this.specialAcademicProgramCheckbox = false;
    this.specialAcademicProgram = 'ACTING_BFA';
  }
}

export class SubmissionSearchCache {
  public response: any;
  public search: SearchCriteria;
  public pageConfig: PageConfig;
  public sortConfig: SortConfig;

  constructor() {
    this.response = null;
    this.search = new SearchCriteria();
    this.pageConfig = new PageConfig();
    this.sortConfig = new SortConfig();
  }

  public getQueryObject(): any {
    const params = {
      objects: {},
      set(key: string, value: string) {
        this.objects[key] = value;
      }
    };

    const criteria = this.search;
    const pageConfig = this.pageConfig;
    const sortConfig = this.sortConfig;

    const searchType: SearchType = +criteria.searchType;

    if (searchType === SearchType.PSU_ID
      || searchType === SearchType.SCHOOL_NAME
      || searchType  === SearchType.CEEB_CODE) {
        if (criteria.searchTextValue && criteria.searchTextValue.trim().length > 0) {
          params.set('searchType', SearchType[criteria.searchType]);
          params.set('searchTextValue', criteria.searchTextValue);
        }
    } else if (searchType === SearchType.STUDENT_NAME) {
      let isPop = false;
      if (criteria.searchFirstNameValue && criteria.searchFirstNameValue.trim().length > 0) {
        isPop = true;
        params.set('searchFirstNameValue', criteria.searchFirstNameValue);
      }
      if (criteria.searchMiddleNameValue && criteria.searchMiddleNameValue.trim().length > 0) {
        isPop = true;
        params.set('searchMiddleNameValue', criteria.searchMiddleNameValue);
      }
      if (criteria.searchLastNameValue && criteria.searchLastNameValue.trim().length > 0) {
        isPop = true;
        params.set('searchLastNameValue', criteria.searchLastNameValue);
      }
      if (isPop === true) {
        params.set('searchType', SearchType[criteria.searchType]);
      }
    }
    if (criteria.fromDateCreated) {
      params.set('fromDateCreated', criteria.fromDateCreated.formatted);
    }

    if (criteria.toDateCreated) {
      params.set('toDateCreated', criteria.toDateCreated.formatted);
    }

    if (criteria.startDate) {
      params.set('startDate', criteria.startDate.formatted);
    }

    if (criteria.endDate) {
      params.set('endDate', criteria.endDate.formatted);
    }

    if (criteria.status) {
      params.set('status', criteria.status);
    }
    if (criteria.schoolLocation) {
      params.set('schoolLocation', criteria.schoolLocation);
      params.set('schoolLocationAdditional', criteria.schoolLocationAdditional);
      params.set('schoolLocationAdditionalExclude', criteria.schoolLocationAdditionalExclude.toString());
    }
    if (criteria.sourceOfRecord) {
      params.set('sourceOfRecord', criteria.sourceOfRecord);
    }
    if (criteria.citizenship) {
      params.set('citizenship', criteria.citizenship);
    }
    if (criteria.specialAcademicProgramCheckbox && criteria.specialAcademicProgram) {
      params.set('specialAcademicProgram', criteria.specialAcademicProgram);
    }
    if (criteria. decileRankUsed) {
      params.set(' decileRankUsed', criteria. decileRankUsed);
    }

    if (criteria.submittedApp && criteria.campusSelection) {
      params.set('campus', criteria.campusSelection);
    }

    if (pageConfig.currentPage) {
      let finalNum = 0;
      if (pageConfig.currentPage > 0) {
        finalNum = pageConfig.currentPage - 1;
      }
      params.set('pageNum', finalNum.toString());
    }

    if (pageConfig.itemsPerPage) {
      params.set('recordsPerPage', pageConfig.itemsPerPage.toString());
    }

    if (sortConfig.sortBy) {
      params.set('sortBy', sortConfig.sortBy);
    }

    if (sortConfig.sortOrder) {
      params.set('sortOrder', sortConfig.sortOrder);
    }
    return params.objects;
  }
}
