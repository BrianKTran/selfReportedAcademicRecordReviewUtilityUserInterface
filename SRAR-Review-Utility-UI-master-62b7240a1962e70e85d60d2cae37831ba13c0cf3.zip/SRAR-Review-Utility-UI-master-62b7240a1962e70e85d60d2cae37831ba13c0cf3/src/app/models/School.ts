export class School {

  public code: string;
  public extOrgId: string;
  public name: string;
  public city: string;
  public state: string;
  public country: string;
  public status: string;
  public zip: string;
  public street1: string;
  public street2: string;
  public blueRibbon: string;
  public highSchoolExpired: string;
  public highSchoolProvince: string;
  public highSchoolType: string;

  constructor() {
    this.code = null;
    this.extOrgId = null;
    this.name = null;
    this.city = null;
    this.state = null;
    this.country = null;
    this.status = null;
    this.zip = null;
    this.street1 = null;
    this.street2 = null;
    this.blueRibbon = null;
    this.highSchoolExpired = null;
    this.highSchoolProvince = null;
    this.highSchoolType = null;
  }

  public static formatAddress(school: School) {

    let formattedAddress = '';

    if (school.street1 && school.street1.trim().length > 0) {
      formattedAddress += school.street1.trim();
    }
    if (school.city && school.city.trim().length > 0) {
      formattedAddress += ', ' + school.city.trim();
    }
    if (school.state && school.state.trim().length > 0) {
      formattedAddress += ', ' + school.state.trim().toUpperCase();
    } else if (school.highSchoolProvince && school.highSchoolProvince.trim().length > 0) {
      formattedAddress += ', ' + school.highSchoolProvince.trim().toUpperCase();
    }
    if (school.zip && school.zip.trim().length > 0) {
      formattedAddress += ' ' + school.zip;
    }
    if (school.country && school.country.trim().length > 0) {
      formattedAddress += ' ' + school.country.trim().toUpperCase();
    }

    return formattedAddress;

  }

}
