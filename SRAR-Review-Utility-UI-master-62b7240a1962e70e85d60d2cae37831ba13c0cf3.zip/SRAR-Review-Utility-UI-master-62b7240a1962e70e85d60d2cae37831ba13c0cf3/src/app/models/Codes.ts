export class CodeBundle {

  public lionpathCodes: VendorBundle;
  public countryCodes: Array<any>;
  public campusCodes: Array<any>;
  public specialAcademicProgramCodes: Array<SpecialAcademicProgramCode>;

  constructor(bundle: CodeBundle) {
    this.lionpathCodes = new VendorBundle(bundle.lionpathCodes);
    this.countryCodes = bundle.countryCodes;
    this.campusCodes = bundle.campusCodes;
    this.specialAcademicProgramCodes = bundle.specialAcademicProgramCodes;
  }
}


export class VendorBundle {

  public allowableGradeCodes: Array<AllowableGradeCode>;
  public courseLevelCodes: Array<CourseLevelCode>;
  public courseNumberCodes: Array<CourseNumberCode>;
  public sessionCodes: Array<SessionCode>;
  public subjectCodes: Array<SubjectCode>;
  public yearCodes: Array<YearCode>;

  constructor(bundle: VendorBundle) {
    this.allowableGradeCodes = bundle.allowableGradeCodes;
    this.courseLevelCodes = bundle.courseLevelCodes;
    this.courseNumberCodes = bundle.courseNumberCodes;
    this.sessionCodes = bundle.sessionCodes;
    this.subjectCodes = bundle.subjectCodes;
    this.yearCodes = bundle.yearCodes;
  }

  public get courseLevelMap() {
    const ret = {};
    this.courseLevelCodes.map((obj => ret[obj.levelCode] = obj.levelValue));
    return ret;
  }
  public get sessionMap() {
    const ret = {};
    this.sessionCodes.map((obj => ret[obj.sessionCode] = obj.sessionValue));
    return ret;
  }
  public get subjectMap() {
    const ret = {};
    this.subjectCodes.map((obj => ret[obj.subjectCode] = obj.subjectValue));
    return ret;
  }
  public get gradeMap() {
    const ret = {};
    this.allowableGradeCodes.map((obj => ret[obj.lpCode] = obj.lpValue));
    return ret;
  }
  public get yearMap() {
    const ret = {};
    this.yearCodes.map((obj => ret[obj.yearCode] = obj.yearValue));
    return ret;
  }


}

export class SpecialAcademicProgramCode {
  public code: string;
  public value: string;
}

export class AllowableGradeCode {

  public lpEnum: number;
  public lpCode: string;
  public lpValue: string;

}

export class CourseLevelCode {

  public lpEnum: number;
  public levelCode: string;
  public levelValue: string;
}

export class CourseNumberCode {
  public courseNumberId: number;
  public subjectCode: string;
  public courseCode: string;
  public courseName: string;
}

export class SessionCode {
  public lpEnum: number;
  public sessionCode: string;
  public sessionValue: string;
}

export class SubjectCode {
  public lpEnum: number;
  public subjectCode: string;
  public subjectValue: string;
}

export class YearCode {
  public id: number;
  public yearCode: number;
  public yearValue: number;
}
