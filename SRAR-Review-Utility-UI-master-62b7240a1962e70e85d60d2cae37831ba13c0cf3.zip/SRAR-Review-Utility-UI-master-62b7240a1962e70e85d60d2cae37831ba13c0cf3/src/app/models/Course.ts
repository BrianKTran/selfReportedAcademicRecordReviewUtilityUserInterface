export class Course {

    public courseId: number;
    public courseSubjectAreaCode: string;
    public courseNumber: string;
    public courseTitle: string;
    public courseLevel: string;
    public sessionAcademicYearCode: string;
    public sessionType: string;
    public courseCreditValue: string;
    public courseAcademicGrade: string;
    public psuId: string;
    public recordId: number;
    public extOrgId: number;
    public ceebCode: string;
    public reportedCourseCreditValue: string;

  constructor() {}

}
