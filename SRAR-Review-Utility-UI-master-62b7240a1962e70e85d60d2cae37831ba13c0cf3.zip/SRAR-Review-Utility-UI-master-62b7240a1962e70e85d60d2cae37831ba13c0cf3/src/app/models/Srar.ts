import { School } from './School';

export class Srar {

  public recordId: number;
  public psuId: string;
  public startDate: string;
  public endDate: string;
  public creditHoursAttempted: number;
  public creditHoursEarned: number;
  public gpa: number;
  public ceebCode: string;
  public externalOrgId: number;
  public classRank: number;
  public classSize: number;
  public decileRankeUsed: string;
  public decileRankSelection: string;
  public homeSchool: string;
  public nonRankingSchool: string;
  public graduationYear: string;
  public studentLevelCode: string;
  public dateCreated: string;
  public school: School;

  constructor() {
    this.recordId = null;
    this.psuId = null;
    this.startDate = null;
    this.endDate = null;
    this.creditHoursAttempted = null;
    this.creditHoursEarned = null;
    this.gpa = null;
    this.ceebCode = null;
    this.externalOrgId = null;
    this.classRank = null;
    this.classSize = null;
    this.decileRankeUsed = 'N';
    this.decileRankSelection = '';
    this.homeSchool = 'N';
    this.nonRankingSchool = 'N';
    this.graduationYear = null;
    this.studentLevelCode = null;
    this.dateCreated = null;
    this.school = null;
  }
}
