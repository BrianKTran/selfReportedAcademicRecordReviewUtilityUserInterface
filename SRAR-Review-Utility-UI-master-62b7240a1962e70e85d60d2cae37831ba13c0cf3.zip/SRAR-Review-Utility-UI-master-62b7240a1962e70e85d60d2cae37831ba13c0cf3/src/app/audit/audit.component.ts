import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Config } from '../config.service';

@Component({
    selector: 'app-audit-list',
    templateUrl: './audit.component.html'
})

export class AuditComponent implements OnInit {

  @Input()
  private psuId: string;
  public audits: Array <any>;

  public sortBy = 'timeStamp';
  public sortOrder = 'asc';

  private readonly BaseUrl = null;

  constructor(private http: HttpClient, private config: Config) {
    this.BaseUrl =  config.getApiUrl() + 'submissions/';
  }

  ngOnInit() {
    this.getAudits(this.psuId);
  }

  getAudits(psuId: string) {

    const url = this.BaseUrl + psuId + '/auditLog';

    this.http.get<Array<any>>(url)
    .subscribe(data => {
      this.audits = data;
    });

  }

}
