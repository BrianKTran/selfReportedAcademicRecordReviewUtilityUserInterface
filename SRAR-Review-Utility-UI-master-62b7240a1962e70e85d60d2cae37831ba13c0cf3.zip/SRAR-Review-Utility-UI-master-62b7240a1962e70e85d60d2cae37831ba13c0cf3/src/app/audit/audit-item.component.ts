import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: '[audit]',
  template: `
  <td>{{audit.psuId}} </td>
  <td>{{audit.recordId || '-'}} </td>
  <td>{{audit.courseId || '-'}}</td>
  <td>{{audit.actionTaken || '-'}}</td>
  <td>{{audit.actionBy || '-'}}</td>
  <td>{{audit.description || '-'}}</td>
  <td>{{(audit.timeStamp | date: 'MM/dd/yyyy, hh:mm:ss a, Z') || '-'}}</td>`

})
export class AuditItemComponent implements OnInit {

  @Input()
  public audit: any;

  constructor() {}

  ngOnInit() {

  }
}
