export class Config {

  private user = null;
  private serverlevel = null;
  private apiUrl = null;
  private logoutUrl = null;

  constructor() {}

  public load(): void {

    this.user = window['_cgi_'].user;
    this.serverlevel = window['_cgi_'].serverlevel;
    this.apiUrl = window['_cgi_'].apiUrl;
    this.logoutUrl = window['_cgi_'].logoutUrl;
  }

  public isProduction(): boolean {
    return this.serverlevel === 'PROD';
  }

  public getServerlevel(): string {
    return this.serverlevel;
  }

  public getUser(): string {
    return this.user;
  }

  public getApiUrl(): string {
    return this.apiUrl;
  }

  public getLogoutUrl(): string {
    return this.logoutUrl;
  }

}
