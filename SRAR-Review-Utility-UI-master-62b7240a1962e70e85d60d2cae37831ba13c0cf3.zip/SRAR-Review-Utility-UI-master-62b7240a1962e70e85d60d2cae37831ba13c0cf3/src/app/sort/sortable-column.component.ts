import {Component, OnInit, Input, HostListener, OnDestroy} from '@angular/core';
import {ColumnSortedEvent, SortService} from './sort.service';
import {Subscription} from 'rxjs/Subscription';

@Component({
  selector: 'app-sortable-column',
  template: `
    <a style="cursor: pointer" class="text-nowrap">
      <ng-content></ng-content>
      <ng-container *ngIf="sortDirection; else noSort">
        <span *ngIf="sortDirection === 'asc'" class="fa fa-sort-up" aria-hidden="true"></span>
        <span *ngIf="sortDirection === 'desc'" class="fa fa-sort-down" aria-hidden="true"></span>
      </ng-container>
      <ng-template #noSort>
        <span class="fa fa-sort" aria-hidden="true"></span>
      </ng-template>
    </a>`
})
export class SortableColumnComponent implements OnInit, OnDestroy {
  @Input() public readonly sortColumn: string;
  @Input() public readonly sortFunc?: Function;
  sortDirection = '';


  private sortServiceSubscription: Subscription = null;

  public constructor(private sortService: SortService) {
  }

  private checkSelfSort() {
    if (this.sortColumn === this.sortService.sortColumn) {
      this.sortDirection = this.sortService.sortDirection;
    } else {
      this.sortDirection = '';
    }
  }

  public ngOnInit(): void {
    // Register this child column key and potential function to service
    this.sortService.registerSortableColumnFunction(this.sortColumn, this.sortFunc);
    this.sortServiceSubscription = this.sortService.sortChanged$.subscribe(() => {
      this.checkSelfSort();
    });
    this.checkSelfSort();
  }

  public ngOnDestroy(): void {
    this.sortServiceSubscription.unsubscribe();
  }

  @HostListener('click')
  sort() {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.sortService.sortColumn = this.sortColumn;
    this.sortService.sortDirection = this.sortDirection;
  }
}
