import {Injectable, OnDestroy} from '@angular/core';
import {debounceTime} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class SortService implements OnDestroy {

  private _data: Array<any>;

  private sortSub: Subscription;

  private _sortColumn: string;
  private _sortDirection: string;

  private registeredSortableColumnFunctions: {[columnName: string]: Function} = {};

  private sortChangedSource = new Subject();
  public sortChanged$ = this.sortChangedSource.pipe(debounceTime(50));

  private dataChangedSource = new Subject();
  public dataChanged$ = this.dataChangedSource.asObservable();

  constructor() {
    this.sortSub = this.sortChanged$.subscribe(() => {
      this.performInternalSort();
    });
  }

  ngOnDestroy() {
    this.sortSub.unsubscribe();
  }

  public set data(val: Array<any>) {
    this._data = val;
  }

  public get data() {
    return this._data;
  }

  public set sortColumn(val: string) {
    const oldVal = this._sortColumn;
    this._sortColumn = val;
    if (oldVal !== val) {
      this.sortChangedSource.next();
    }
  }

  public set sortDirection(val: string) {
    const oldVal = this._sortDirection;
    this._sortDirection = val;
    if (oldVal !== val) {
      this.sortChangedSource.next();
    }
  }

  public get sortColumn() {
    return this._sortColumn;
  }

  public get sortDirection() {
    return this._sortDirection;
  }

  public registerSortableColumnFunction(columnName: string, func: Function) {
    this.registeredSortableColumnFunctions[columnName] = func;
  }

  public performInternalSort() {
    // If we weren't given data, then sort is happening externally. Don't do anything
    if (this._data === null || this._data === undefined || this._data.length === 0) {
      return;
    }
    const func = this.registeredSortableColumnFunctions[this._sortColumn];
    const reverse: number = this._sortDirection === 'asc' ? 1 : -1;
    this._data.sort((a, b) => {
      let val1: string;
      let val2: string;
      // If transform function is provided, transform the data;
      if (func && typeof func === 'function') {
        val1 = func(a) || '';
        val2 = func(b) || '';
      } else {
        // Determine if sortColumn is a reference chain
        const colRef: string[] = this._sortColumn.split('.');
        let obj1 = a;
        let obj2 = b;
        for (const colVal of colRef) {
          obj1 = obj1[colVal];
          obj2 = obj2[colVal];
        }
        val1 = obj1 || '';
        val2 = obj2 || '';
      }
      const num1: number = Number(val1);
      const num2: number = Number(val2);
      let sResult = 0;
      // If not numbers, then sort as string
      if (isNaN(num1) && isNaN(num2)) {
        sResult = reverse * val1.localeCompare(val2);
      }
      // If both are numbers
      if (!isNaN(num1) && !isNaN(num2)) {
        sResult = reverse * (num1 - num2);
      }
      // If first is string and second is number
      if (isNaN(num1) && !isNaN(num2)) {
        sResult = reverse * (1);
      }
      // If first is number and second is string
      if (!isNaN(num1) && isNaN(num2)) {
        sResult = reverse * (-1);
      }
      if (sResult === 0) {
        const aK = Object.keys(a).map(key => a[key]).reduce((r, c) => r + c);
        const bK = Object.keys(b).map(key => b[key]).reduce((r, c) => r + c);
        sResult = aK.localeCompare(bK);
      }
      return sResult;
    });
    this.dataChangedSource.next();
  }
}

export interface ColumnSortedEvent {
  sortColumn: string;
  sortDirection: string;
}
