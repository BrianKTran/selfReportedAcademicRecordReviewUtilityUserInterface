import {Directive, EventEmitter, OnDestroy, OnInit, Input, Output, AfterViewInit} from '@angular/core';
import {ColumnSortedEvent, SortService} from './sort.service';
import {Subscription} from 'rxjs/Subscription';

@Directive({
  selector: '[appSortableTable]',
  providers: [SortService],
  exportAs: 'csSortableTable'
})
export class SortableTableDirective implements OnInit, OnDestroy {

  private sortChangedSub: Subscription = null;
  private dataChangedSub: Subscription = null;

  @Output() sortColumnChange = new EventEmitter();
  @Output() sortDirectionChange = new EventEmitter();
  @Output() appSortableTableChange = new EventEmitter();

  @Output() onSort = new EventEmitter<ColumnSortedEvent>();

  constructor(private sortService: SortService) {}

  @Input()
  set appSortableTable(data: Array<any>) {
    this.sortService.data = data;
  }

  @Input()
  set sortColumn(val: string) {
    this.sortService.sortColumn = val;
  }

  @Input()
  set sortDirection(val: string) {
    this.sortService.sortDirection = val;
  }

  get data() {
    return this.sortService.data;
  }

  public ngOnInit(): void {
    this.sortChangedSub = this.sortService.sortChanged$
      .subscribe(() => {
        this.sortColumnChange.emit(this.sortService.sortColumn);
        this.sortDirectionChange.emit(this.sortService.sortDirection);
        this.onSort.emit({sortColumn: this.sortService.sortColumn, sortDirection: this.sortService.sortDirection});
    });
    this.dataChangedSub = this.sortService.dataChanged$.subscribe(() => {
      this.appSortableTableChange.emit(this.sortService.data);
    });
  }

  public ngOnDestroy(): void {
    this.sortChangedSub.unsubscribe();
    this.dataChangedSub.unsubscribe();
  }

}
