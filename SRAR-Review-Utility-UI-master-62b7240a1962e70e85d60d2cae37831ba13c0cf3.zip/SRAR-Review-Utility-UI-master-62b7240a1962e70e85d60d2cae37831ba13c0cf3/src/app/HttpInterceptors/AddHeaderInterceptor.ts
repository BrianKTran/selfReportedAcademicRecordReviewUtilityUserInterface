import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest, HttpErrorResponse,
} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {Config} from '../config.service';
import {catchError} from 'rxjs/operators';
import {empty} from 'rxjs/observable/empty';

export class AddHeaderInterceptor implements HttpInterceptor {

  constructor(private config: Config) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Clone the request to add the new header
    const clonedRequest = req.clone({ headers: req.headers.set('Authorization', this.config.getUser()) });

    // Pass the cloned request instead of the original request to the next handle
    return next.handle(clonedRequest).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          // A client-side or network error occurred. Handle it accordingly.
          alert(`An error occurred: ${err.error.message}`);
        } else {
          alert(`Server error code ${err.status}\nBody was: ${JSON.stringify(err.error)}`);
        }
        return empty<HttpEvent<any>>();
      }));
  }
}
