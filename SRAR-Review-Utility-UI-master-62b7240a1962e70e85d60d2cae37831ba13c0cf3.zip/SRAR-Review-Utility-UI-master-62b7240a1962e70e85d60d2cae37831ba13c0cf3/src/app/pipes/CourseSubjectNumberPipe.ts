import {Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'courseSubject'})
export class CourseSubjectNumberPipe implements PipeTransform {
  transform(codes: Array<any>, subject: string) {
      if (codes && codes.length > 0) {
        return codes.filter((code) => {
          if (subject) {
            return code.subjectCode === subject;
          }
          return true;
        });
      }
      return [];
  }
}
