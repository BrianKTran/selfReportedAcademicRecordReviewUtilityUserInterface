import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubmissionDetailComponent } from '../submission/submission-detail/submission-detail.component';
import { SubmissionListComponent } from '../submission/submission-list/submission-list.component';

const appRoutes: Routes = [
  { path: '', redirectTo: 'submissions', pathMatch: 'full'},
  { path: 'submissions', component: SubmissionListComponent },
  { path: 'submissions/:psuId', component: SubmissionDetailComponent },
  { path: '**', redirectTo: 'submissions', pathMatch: 'full'}
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
        { useHash: true,
          enableTracing: false }
    )
  ],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AppRoutingModule {}
