var fs = require('fs');

fs.readFile('./dist/index.html', 'utf8', function(err, data) {
  if (err) {
    console.log("Error reading index.html");
    return false;
  }

  var baseStart = data.indexOf("<base");
  var baseEnd = data.indexOf(">", baseStart);

  var cfmData = data.substring(0, baseStart)
  + '<base href="/intranet/utilities/srar/srar.cfm">'
  + data.substring(baseEnd + 1, data.length);

  fs.writeFile("./dist/srar.cfm", cfmData, function(err) {
    if (err) {
      console.log("Error writing srar.cfm");
      return false;
    }

    console.log("created ./dist/srar.cfm");
    fs.unlink('./dist/index.html', function(err) {
      if (err) {
        console.log("Error deleting index.html");
        return false;
      }

      console.log('deleted ./dist/index.html');
    });
  });

  copyFile('./src/index.cfm', './dist/index.cfm', function(err) {
    if (err) {
      console.log("Error copying index.cfm");
    } else {
      console.log("copied ./src/index.cfm to ./dist/index.cfm");
    }
  });

});


function copyFile(source, target, cb) {
  var cbCalled = false;

  var rd = fs.createReadStream(source);
  rd.on("error", function(err) {
    done(err);
  });
  var wr = fs.createWriteStream(target);
  wr.on("error", function(err) {
    done(err);
  });
  wr.on("close", function(ex) {
    done();
  });
  rd.pipe(wr);

  function done(err) {
    if (!cbCalled) {
      cb(err);
      cbCalled = true;
    }
  }
}
