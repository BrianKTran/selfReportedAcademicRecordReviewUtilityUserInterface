import { SRARReviewUtilityUIPage } from './app.po';

describe('srar-review-utility-ui App', () => {
  let page: SRARReviewUtilityUIPage;

  beforeEach(() => {
    page = new SRARReviewUtilityUIPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
